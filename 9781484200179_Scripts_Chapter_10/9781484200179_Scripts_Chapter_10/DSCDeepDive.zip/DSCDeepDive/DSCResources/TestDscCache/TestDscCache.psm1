﻿
$svcname = "system"
function Get-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
        $dummy
    )
    return @{dummy = Test-Path "${env:SystemDrive}\Process.txt" -ErrorAction SilentlyContinue}
}

function Set-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
        $dummy
    )
    Get-Process -Name "$svcname" | Out-File "${env:SystemDrive}\Process.txt"
}

function Test-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
        $dummy
    )
    return $false
}